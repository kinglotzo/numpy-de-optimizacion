mealpy.music\_based package
===========================

mealpy.music\_based.HS module
-----------------------------

.. automodule:: mealpy.music_based.HS
   :members:
   :undoc-members:
   :show-inheritance:
