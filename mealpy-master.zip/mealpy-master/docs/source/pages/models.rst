

.. toctree::
   :maxdepth: 4

   models/mealpy.rst
   general/visualization.rst
   general/build_new_optimizer.rst
   general/tuner.rst
   general/multitask.rst

.. toctree::
   :maxdepth: 4


.. toctree::
   :maxdepth: 4
